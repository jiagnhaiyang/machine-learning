def hello(name):
    print("Hello", name, "!")

hello("Machine Learning")