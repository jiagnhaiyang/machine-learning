def predict(x):
    print("?")